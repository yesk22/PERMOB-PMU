# Contribuindo

1. Crie uma branch: `feat/<slug>` ou `fix/<slug>`
2. Commits curtos e frequentes.
3. Abra PR com checklist DoD e link para a thread do Slack.
4. Solicite review dos **CODEOWNERS**.
