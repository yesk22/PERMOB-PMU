## Objetivo
Descreva o que este PR entrega (ligado a qual história/KPI).

## Checklist (DoD)
- [ ] KPI/feature calculado(a) e validado(a) (amostra >= 10 municípios)
- [ ] Visual pronto (card/tabela/série) com rótulos e nota metodológica
- [ ] README/Changelog atualizados
- [ ] Demonstração (screenshot/arquivo) anexada
- [ ] Feedback coletado e próximos passos enviados ao backlog

## Referências
Links para threads do Slack, issues, documentos, etc.
