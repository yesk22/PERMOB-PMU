# Changelog

Todas as mudanças notáveis deste projeto.

## [Unreleased]

## [0.1.0] - 2025-09-15
### Added
- Bootstrap do repositório: estrutura, CI, templates, script de ETL mínimo.
